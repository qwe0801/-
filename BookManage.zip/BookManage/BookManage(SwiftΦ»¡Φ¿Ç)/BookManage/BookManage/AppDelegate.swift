//
//  AppDelegate.swift
//  BookManageYWJ
//
//  Created by qwe on 2022/6/15.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window:UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        self.window = UIWindow(frame: UIScreen.main.bounds)
        self.window?.backgroundColor = UIColor.white
        let rootVC = MainViewController()
//        var rootVC = UIViewController()
//        //验证是否登录
//        let manager = UserDefaults()
//        if manager.string(forKey:"UserID") != nil {
//            rootVC = MainViewController()
//        } else {
//            rootVC = LoginViewController()
//        }
        
        self.window?.rootViewController = rootVC
        self.window?.makeKeyAndVisible()

        return true
    }
}


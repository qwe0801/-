//
//  BookKindNetwork.swift
//  BookManage
//
//  Created by qwe on 2022/6/14.
//

import Foundation
class BookKindNetwork {
    static func getAllBookKind(finishedCallback: @escaping (_ result:[String: Any]) -> (),failture: @escaping ()->()) {
        let url = GlobalDefine.baseURL  + "findAllBookKind"
        NetworkTool.shareInstance.requestJsonData(.get, URLString: url) { response in
            finishedCallback(response)
        } failture: { _ in
            failture()
        }
    }
    
}

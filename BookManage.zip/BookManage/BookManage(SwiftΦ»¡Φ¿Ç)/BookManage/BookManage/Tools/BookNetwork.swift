//
//  BookNetwork.swift
//  BookManage
//
//  Created by qwe on 2022/5/31.
//

import Foundation
class BookNetwork {
    static func findBookById(parameters:[String:Any]? = nil,
                              finishedCallback: @escaping (_ result:[String:Any])->(),
                              failture: @escaping ()->()) {
            let url = GlobalDefine.baseURL + "findBookById"
            NetworkTool.shareInstance.requestJsonData(.get, URLString: url, parameters: parameters, success: {
                (response) in
                print(response)
                finishedCallback(response)
            }) {
                (_) in
                failture()
            }
        }
    static func findBookByBookKindId(parameters:[String:Any]? = nil,
                              finishedCallback: @escaping (_ result:[String:Any])->(),
                              failture: @escaping ()->()) {
            let url = GlobalDefine.baseURL + "findBookByBookKindId"
            NetworkTool.shareInstance.requestJsonData(.get, URLString: url, parameters: parameters, success: {
                (response) in
                print(response)
                finishedCallback(response)
            }) {
                (_) in
                failture()
            }
        }
        static func updateBookById(parameters:[String:Any]? = nil,
                              finishedCallback: @escaping (_ result:[String:Any])->(),
                              failture: @escaping ()->()) {
            let url = GlobalDefine.baseURL + "updateBookById"
            NetworkTool.shareInstance.requestJsonData(.get, URLString: url, parameters: parameters, success: {
                (response) in
                print(response)
                finishedCallback(response)
            }) {
                (_) in
                failture()
            }
        }
    
}


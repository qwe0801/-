//
//  BookDetailViewController.swift
//  BookManage
//
//  Created by qwe on 2022/6/14.
//

import UIKit
import SVProgressHUD
import Alamofire

class BookDetailViewController: UIViewController {
    @IBOutlet weak var bookID: UITextField!
    
    @IBOutlet weak var bookName: UITextField!
    
    @IBAction func updateButton(_ sender: Any) {
        updateBookById()
    }
    @IBOutlet weak var bookPrice: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getBook()
    }
    var bookId: Int?
    var books: bookModel?
    var book: [bookBaseModel]?
    func getBook() {
            SVProgressHUD.show(withStatus: "加载中")
            let parameters:Parameters = [
               "bookId":self.bookId!
            ]
            BookNetwork.findBookById(parameters: parameters) { response in
                print(response)
                self.books = bookModel(JSON: response)
                self.book = self.books?.result
                for item in self.book! {
                    self.bookID.text = (item.bookID!).description
                    self.bookName.text = item.bookName
                    self.bookPrice.text = item.bookPrice
                }
                SVProgressHUD.dismiss()
            } failture: {
                print("发生错误：\(#function)")
            }
        }
        
        func updateBookById() {
            let paramters: Parameters = [
                "bookId": self.bookId!,
                "bookName": self.bookName.text!,
                "bookPrice": self.bookPrice.text!
            ]
            BookNetwork.updateBookById(parameters: paramters) { response in
                SVProgressHUD.showInfo(withStatus: "修改成功")
                SVProgressHUD.dismiss(withDelay: 2)
            } failture: {
                print("发生错误：\(#function)")
            }

        }
    
}

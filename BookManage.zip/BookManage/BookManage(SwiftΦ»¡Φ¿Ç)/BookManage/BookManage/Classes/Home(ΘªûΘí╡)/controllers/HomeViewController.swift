//
//  HomeViewController.swift
//  BookManageYWJ
//
//  Created by qwe on 2022/6/14.
//

import UIKit
import Alamofire
import SDCycleScrollView
import SVProgressHUD
import SnapKit
 
class HomeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource,UITableViewDelegate, UITableViewDataSource, SDCycleScrollViewDelegate {
   
    // 轮播图
    lazy var bannerScrollView:SDCycleScrollView = {
        var bannerScrollView = SDCycleScrollView()
       
        let img1 = UIImage(named:"bannerimg1")
        let img2 = UIImage(named:"bannerimg2")
        let img3 = UIImage(named:"bannerimg3")
        let img4 = UIImage(named:"bannerimg4")
        let img5 = UIImage(named:"bannerimg5")
       
        let imgArray = [img1, img2, img3, img4,img5]
       
        bannerScrollView = SDCycleScrollView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height:SDCycleScrollViewHeight), imageNamesGroup: imgArray as! [UIImage])
       
        bannerScrollView.bannerImageViewContentMode = .scaleToFill
        bannerScrollView.showPageControl = true
        bannerScrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter
        bannerScrollView.autoScroll = true
        bannerScrollView.autoScrollTimeInterval = 5
        bannerScrollView.infiniteLoop = true
       
        return bannerScrollView
    }()
   
    lazy var netImages:[UIImage] = {
        let url = URL(string: "path")
        var image1 = UIImage()
        var image2 = UIImage()
        do {
            let data = try Data(contentsOf:url!)
            image1 = UIImage(data: data)!
            image2 = UIImage(data: data)!
        } catch let error as NSError {
            print(error)
        }
        return [image1,image2]
    }()
   
    //懒加载本地图片数据
    lazy var localImages:[UIImage] = {
            let img1 = UIImage(named:"bannerimg1")
            let img2 = UIImage(named:"bannerimg2")
            let img3 = UIImage(named:"bannerimg3")
            let img4 = UIImage(named:"bannerimg4")
            let img5 = UIImage(named:"bannerimg5")
            return [img1!, img2!, img3!, img4!,img5!]
        }()
   
    var cycleScrollView = SDCycleScrollView()
   
    //分类列表
    @IBOutlet weak var bookKindCollectionView: UICollectionView!
    @IBOutlet weak var bookTableview: UITableView!
    
    lazy var noInfoLabel : UILabel = {
        let label = UILabel.init(frame:CGRect(x:0,y:self.bookTableview.center.y - 64,width:ScreenWidth,height:30))
        label.text = "该分类下暂无设备"
        label.font = UIFont.init(name:"noinfo", size: 16)
        label.textColor = UIColor.black
        label.textAlignment = .center
        return label
    }()
   
    //设备分类collectionView的数据源
    var bookKindModelArray:bookKindModel?
    var bookKindBaseModelArray:[bookKindBaseModel]?
    //设备tableView的数据源
    var bookModelArray:bookModel?
    var bookBaseModelArray:[bookBaseModel]?
   
   
    var classIdArray:[Int] = []
    var classNameArray:[String] = []
    var bookIdArray:[Int] = []
    var bookNameArray:[String] = []
    var bookPriceArray:[String] = []
   
    var bookKindNames:[String]?
    var bookKindIds:[Int]?
   
    var bookKindId:Int?
   
    //各控件所需尺寸定义
    let SDCycleScrollViewHeight = ScreenHeight / 3
    let UICollectionViewHeight = ScreenHeight / 4
    let UITableViewViewCellHeight:CGFloat = ScreenHeight / 7
    let CollectionCellHeight:CGFloat = 80
   
    override func viewDidLoad() {
        super.viewDidLoad()
        self.edgesForExtendedLayout = .bottom
       
        self.title = "首页"
        // Do any additional setup afterloading the view.
        self.setupUI()
    }
   
    func setupUI() {
        self.setupSDcycleScrollView()
        self.setupCollectionView()
        self.setupTableView()
    }
   
    func setupSDcycleScrollView() {       
        self.bannerScrollView.delegate = self
        self.view.addSubview(self.bannerScrollView)
    }
   
    func cycleScrollView(_ cycleScrollView:SDCycleScrollView!, didSelectItemAt index: Int) {
        print("点击了第\(index)张图片")
       
        SDCycleScrollView.clearImagesCache()
    }
   
    func cycleScrollView(_ cycleScrollView:SDCycleScrollView!, didScrollTo index: Int) {
        print(">>>>>滚动到第\(index)张图片")
    }
   
    func setupCollectionView() {
       self.view.addSubview(self.bookKindCollectionView)
       self.getAllBookKind()
       
       self.bookKindCollectionView.snp.makeConstraints{ (make) in
           make.top.equalTo(self.bannerScrollView.snp_bottom)
           make.right.equalToSuperview()
           make.left.equalToSuperview()
           make.height.equalTo(UICollectionViewHeight)
        }
       
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width:(ScreenWidth - 4 * 20) / 3 , height: (UICollectionViewHeight - 3 * 10) / 2)
        layout.minimumLineSpacing = 20
        layout.minimumInteritemSpacing = 10
        layout.scrollDirection = .vertical
        layout.sectionInset = UIEdgeInsets(top:5, left: 5, bottom: 5, right: 5)
       
       self.bookKindCollectionView.collectionViewLayout = layout
       
       
       self.bookKindCollectionView.delegate = self
       self.bookKindCollectionView.dataSource = self
       
       self.bookKindCollectionView.register(UINib(nibName:"bookKindCell", bundle: nil), forCellWithReuseIdentifier:"bookKindCell")
       
    }
       
    @objc func getBookByClass(btn:UIButton) {
        // 清空数组
        self.classIdArray = []
        self.bookIdArray = []
        self.bookNameArray = []
        self.bookPriceArray = []
       
        self.bookKindId = btn.tag + 1
       
        self.getAllBookByBookKindId()
    }
   
    func setupTableView() {
       self.view.addSubview(self.bookTableview)
       self.bookTableview.isHidden = true
       self.bookTableview.snp.makeConstraints { (make) in
            make.top.equalTo(self.bookKindCollectionView.snp.bottom)
            make.left.equalToSuperview()
            make.width.equalToSuperview()
            make.bottom.equalToSuperview()
        }
       
        self.bookTableview.delegate = self
        self.bookTableview.dataSource = self
        self.bookTableview.tableFooterView = UIView()
        self.bookTableview.register(UINib(nibName: "bookCell",bundle: nil), forCellReuseIdentifier: "bookCell")
    }
   
    func getAllBookKind() {
        SVProgressHUD.show(withStatus: "加载中")
        BookKindNetwork.getAllBookKind(finishedCallback: { (response) in
            print(response)
            self.bookKindNames = []
            self.bookKindIds = []
           
            self.bookKindModelArray = bookKindModel(JSON: response)
            self.bookKindBaseModelArray = self.bookKindModelArray?.result
            for item in self.bookKindBaseModelArray! {
               self.bookKindNames?.append(item.BookKindName ?? "")
               self.bookKindIds?.append(item.BookKindID!)
            }
            SVProgressHUD.dismiss()
           self.bookKindCollectionView.reloadData()
        }) {
            print("发生错误：\(#function)")
        }       
    }
   
    func getAllBookByBookKindId() {
        SVProgressHUD.show(withStatus: "加载中")
        let parameters:Parameters = [
           "bookKindId":self.bookKindId!
        ]
        BookNetwork.findBookByBookKindId(parameters: parameters,finishedCallback: { (response) in
//            print(response)
            // 清空数组
            self.classIdArray = []
            self.bookIdArray = []
            self.bookNameArray = []
            self.bookPriceArray = []
           
            self.bookTableview.isHidden = false
            self.bookModelArray = bookModel(JSON: response)
            self.bookBaseModelArray = self.bookModelArray?.result
           for item in self.bookBaseModelArray! {
               self.classIdArray.append(item.bookKindId!)
               self.bookIdArray.append(item.bookID!)
               self.bookNameArray.append(item.bookName!)
               self.bookPriceArray.append(item.bookPrice!)
            }
           
            if self.bookIdArray.count == 0 {
                self.bookTableview.isHidden = true
                self.view.addSubview(self.noInfoLabel)
            } else {
               self.noInfoLabel.removeFromSuperview()
                self.bookTableview.isHidden = false
            }
            SVProgressHUD.dismiss()
            self.bookTableview.reloadData()
            
        }) {
            print("发生错误：\(#function)")
        }
    }
   
    //MARK: -实现UITableDataSource协议
    func tableView(_ tableView: UITableView,titleForHeaderInSection section: Int) -> String? {
        return "设备列表"
    }
   
    func numberOfSections(in tableView:UITableView) -> Int {
        return 1
    }
   
    func tableView(_ tableView: UITableView,numberOfRowsInSection section: Int) -> Int {
        if self.bookBaseModelArray != nil {
            return self.bookBaseModelArray!.count
        }
        return 0
    }
   
    func tableView(_ tableView: UITableView,heightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.UITableViewViewCellHeight
    }
   
    func tableView(_ tableView: UITableView,cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell = tableView.dequeueReusableCell(withIdentifier: "bookCell", for:indexPath) as! bookCell
       
        if self.bookBaseModelArray != nil {
            cell.bookName.text = self.bookNameArray[indexPath.row]
            cell.bookPrice.text = self.bookPriceArray[indexPath.row]
           
            switch cell.bookName.text {
            case "涂料与颜料标准汇编":
                cell.bookImgView.image = UIImage(named:"涂料与颜料标准汇编")
            case "石油工业技术经济学院":
                cell.bookImgView.image = UIImage(named: "石油工业技术经济学院")
            case "宋代青白瓷的历史地理研究":
                cell.bookImgView.image = UIImage(named: "宋代青白瓷的历史地理研究")
            default:
                break
            }
        }
       
        return cell
    }
   
    func tableView(_ tableView: UITableView,didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath,animated: true)
        let vc = BookDetailViewController()
        vc.bookId = bookIdArray[indexPath.row]
        vc.hidesBottomBarWhenPushed = true
       self.navigationController?.pushViewController(vc, animated: true)
    }
   
    //MARK: -实现UICollectionViewDataSource协议
    func numberOfSections(in collectionView:UICollectionView) -> Int {
        return 1
    }
   
    func collectionView(_ collectionView:UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if self.bookKindNames != nil {
            return self.bookKindNames!.count
        }
        return 0
    }
   
    func collectionView(_ collectionView:UICollectionView, cellForItemAt indexPath: IndexPath) ->UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"bookKindCell", for: indexPath) as! bookKindCell
        
        if self.bookKindIds != nil {
            switch self.bookKindIds![indexPath.row] {
            case 1:
                cell.imageView.image = UIImage(named: "1")
            case 2:
                cell.imageView.image = UIImage(named: "2")
            case 3:
                cell.imageView.image = UIImage(named: "3")
            case 4:
                cell.imageView.image = UIImage(named: "4")
            case 5:
                cell.imageView.image = UIImage(named: "5")
            default:
                cell.imageView.image = UIImage(named: "")
            }
            cell.titleLabel.text = self.bookKindNames![indexPath.row]
        }
        return cell
    }
   
    //MARK: -实现UICollectionViewDelegate协议
    func collectionView(_ collectionView:UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at:indexPath, animated: true)
        self.bookKindId = indexPath.row + 1
        self.getAllBookByBookKindId()
    }
 
}

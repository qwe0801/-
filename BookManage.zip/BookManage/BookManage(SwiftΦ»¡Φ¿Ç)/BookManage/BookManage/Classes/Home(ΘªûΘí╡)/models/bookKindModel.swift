//
//  bookKindModel.swift
//  BookeManageYWJ
//
//  Created by qwe on 2022/6/14.
//

import Foundation
import ObjectMapper

class  bookKindModel:Mappable{
    var result:[bookKindBaseModel]?
    required init?(map: Map) {
    }
    func mapping(map: Map) {
        result <- map["result"]
    }
}
class  bookKindBaseModel:Mappable {
    var BookKindID:Int?
    var BookKindName:String?
    required init?(map: Map) {
    }
    func mapping(map: Map) {
        BookKindID   <- map["BookKindID"]
        BookKindName <- map["BookKindName"]
    }
}

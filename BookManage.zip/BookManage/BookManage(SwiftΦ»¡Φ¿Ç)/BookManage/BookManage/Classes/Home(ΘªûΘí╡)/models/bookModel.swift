//
//  bookModel.swift
//  BookManageYWJ
//
//  Created by qwe on 2022/6/14.
//

import Foundation
import ObjectMapper
 
class bookModel: Mappable {
    var result:[bookBaseModel]?
   
    required init?(map: Map) {
       
    }
   
    func mapping(map: Map) {
        result <- map["result"]
    }
   
}
 
class bookBaseModel: Mappable {
   
    var bookKindId:Int?
    var bookID:Int?
    var bookName:String?
    var bookPrice:String?
   
    required init?(map: Map) {
       
    }
   
    func mapping(map: Map) {
        bookKindId    <- map["BookKindId"]
        bookID        <- map["BookID"]
        bookName      <- map["BookName"]
        bookPrice     <- map["BookPrice"]
    }
   
}

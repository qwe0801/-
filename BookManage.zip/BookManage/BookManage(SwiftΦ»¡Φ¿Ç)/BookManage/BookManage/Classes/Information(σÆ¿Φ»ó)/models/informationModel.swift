//
//  informationModel.swift
//  DeviceManage
//
//  Created by qwe on 2022/5/10.
//

import Foundation
import ObjectMapper
 
class informationModel:Mappable {
   
    var result:[informationBaseModel]?
      
    required init?(map: Map) {
       
    }
   
    func mapping(map: Map) {
        result <- map["result"]
    }
   
}
 
class   informationBaseModel:Mappable {
   
    var informationContent:String?
    var informationCreateTime:String?
    var informationID:Int?
    var informationImage:String?
   
    required init?(map: Map) {
       
    }
   
    func mapping(map: Map) {
        informationContent      <- map["InformationContent"]
        informationCreateTime   <- map["InformationCreateTime"]
        informationID           <- map["InformationID"]
        informationImage        <- map["InformationImage"]
    }
   
}

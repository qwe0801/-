//
//  InformationViewController.swift
//  DeviceManage
//
//  Created by zjc13 on 2022/5/10.
//

import UIKit

class InformationViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.edgesForExtendedLayout = .bottom
        self.title = "咨询"
    }
}

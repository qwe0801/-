//
//  LoginViewController.swift
//  DeviceManage
//
//  Created by qwe on 2022/5/10.
//

import UIKit
import Alamofire
import SVProgressHUD
class LoginViewController: UIViewController {
    
    @IBOutlet weak var userNameTF: UITextField!
    
    @IBOutlet weak var userPasswordTF: UITextField!
    
    @IBOutlet weak var loginBtn: UIButton!
    
    var userInfo:[userBaseModel]?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title="登录"
        self.loginBtn.addTarget(self, action: #selector(loginCallback),for: .touchUpInside)
    }
    @objc func loginCallback() {
        SVProgressHUD.show(withStatus: "正在登录")
        //准备GET网络请求的2个参数
        let parameters: [String:Any] = [
            "username":self.userNameTF.text!,
            "password":self.userPasswordTF.text!
        ]
        //执行loginValidate接口访问请求
        UserNetwork.loginValidate(parameters: parameters,
        //多尾随闭包的倒数第二个闭包finishedCallback的外部参数没省略
        finishedCallback: { (response) in
    //           print(response)
            //response包含tomcat返回的json字符串
            let model:userModel = userModel(JSON: response)!
            self.userInfo = model.result
            self.writeUserInfo()
            self.showLog()
            
            SVProgressHUD.dismiss()
            self.showMainViewController()
        })
        //多尾随闭包的最后一个闭包failure的外部参数省略
        {
            SVProgressHUD.dismiss()
            SVProgressHUD.showError(withStatus: "登录失败")
            SVProgressHUD.dismiss(withDelay: 1.5)
        }
    }
    func writeUserInfo() {
        let manager = UserDefaults()
        manager.set(self.userInfo?.first?.userID, forKey: "UserID")
        manager.set(self.userInfo?.first?.userName, forKey: "UserName")
        manager.set(self.userInfo?.first?.userPassword, forKey: "UserPassword")
    }
    
    func showLog() {
        print("====================登录服务器信息=================")
        print(UserDefaults.standard.object(forKey: "UserID")!)
        print(UserDefaults.standard.object(forKey: "UserName")!)
        print(UserDefaults.standard.object(forKey:"UserPassword")!)
        print("=================================================")
    }
    

    func showMainViewController() {
        let vc = MainViewController()
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true,completion: nil)
    }
}

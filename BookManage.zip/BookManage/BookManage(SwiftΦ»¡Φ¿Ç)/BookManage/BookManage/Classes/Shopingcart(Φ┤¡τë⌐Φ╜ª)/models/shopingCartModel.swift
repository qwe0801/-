//
//  shopingCartModel.swift
//  DeviceManage
//
//  Created by qwe on 2022/5/10.
//

import Foundation
import ObjectMapper
 
class shopingCartModel: Mappable {
   
    var result:[shopingCartBaseModel]?
   
    required init?(map: Map) { }
   
    func mapping(map: Map) {
        result <- map["result"]
    }
}
 
class shopingCartBaseModel: Mappable {
   
    var ShopingcartID:Int?
    var Device:shopingCartDeviceInfoModel?
    var UserID:Int?
    var BuyNum:Int?
   
    required init?(map: Map) { }
   
    func mapping(map: Map) {
        ShopingcartID   <- map["ShopingcartID"]
        Device          <- map["Device"]
        UserID          <- map["UserID"]
        BuyNum          <- map["BuyNum"]
    }
}
 
class shopingCartDeviceInfoModel: Mappable {
   
    var DeviceID:Int?
    var DeviceClassId:Int?
    var DevicePrice:String?
    var DeviceName:String?
   
    required init?(map: Map) { }
   
    func mapping(map: Map) {
        DeviceID        <- map["DeviceID"]
        DeviceClassId   <- map["DeviceClassId"]
        DevicePrice     <- map["DevicePrice"]
        DeviceName      <- map["DeviceName"]
    }
}

/*
 Navicat Premium Data Transfer

 Source Server         : MYSQL57
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : localhost:3306
 Source Schema         : bookmanageYWJ

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 15/06/2022 21:05:59
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for Book
-- ----------------------------
DROP TABLE IF EXISTS `Book`;
CREATE TABLE `Book` (
  `BookID` int(11) NOT NULL AUTO_INCREMENT,
  `BookKindID` int(11) DEFAULT NULL,
  `BookName` varchar(255) DEFAULT NULL,
  `BookPrice` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`BookID`),
  KEY `BookKindID` (`BookKindID`),
  CONSTRAINT `book_ibfk_1` FOREIGN KEY (`BookKindID`) REFERENCES `bookkind` (`BookKindID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Book
-- ----------------------------
BEGIN;
INSERT INTO `Book` VALUES (1, 1, '涂料与颜料标准汇编', '59');
INSERT INTO `Book` VALUES (2, 1, '石油工业技术经济学院', '38');
INSERT INTO `Book` VALUES (3, 2, '宋代青白瓷的历史地理研究', '58');
INSERT INTO `Book` VALUES (4, 2, '哈哈哈', '12');
COMMIT;

-- ----------------------------
-- Table structure for BookKind
-- ----------------------------
DROP TABLE IF EXISTS `BookKind`;
CREATE TABLE `BookKind` (
  `BookKindID` int(11) NOT NULL AUTO_INCREMENT,
  `BookKindName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`BookKindID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of BookKind
-- ----------------------------
BEGIN;
INSERT INTO `BookKind` VALUES (1, '工业技术');
INSERT INTO `BookKind` VALUES (2, '历史');
INSERT INTO `BookKind` VALUES (3, '英语');
INSERT INTO `BookKind` VALUES (4, '政治');
INSERT INTO `BookKind` VALUES (5, '历史');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;

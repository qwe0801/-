//
//  DetaliController.h
//
//  Created by qwe on 2021/7/2.
//

#import <UIKit/UIKit.h>
#import "Book.h"

@interface DetailController: UIViewController

@property (weak, nonatomic) IBOutlet UITextView *introduce;
@property (weak, nonatomic) IBOutlet UILabel *bookname;
@property (weak, nonatomic) IBOutlet UILabel *price;

@property (weak, nonatomic) IBOutlet UILabel *bookkindname;
@property (weak, nonatomic) IBOutlet UILabel *id;

@property(nonatomic,strong)Book *book;
@end


#import <Foundation/Foundation.h>

@interface Book : NSObject
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *picture;
@property(nonatomic,copy)NSString *detail;
@property(nonatomic,copy)NSString *price;
@property(nonatomic,copy)NSString *id;

+(instancetype)bookWithDict:(NSDictionary *)dict;//声明创建书籍对象的类方法
-(instancetype)initWithDict:(NSDictionary *)dict;//声明创建书籍对象的对象方法
+(NSArray *)books;//声明返回所有酒店的方法
@end


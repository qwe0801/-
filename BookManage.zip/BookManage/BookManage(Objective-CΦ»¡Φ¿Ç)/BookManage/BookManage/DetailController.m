//
//  DetaliController.m
//  HotelManage
//
//  Created by qwe on 2021/7/2.
//

#import "DetailController.h"

@interface DetailController ()

@end

@implementation DetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.bookname.text=self.book.name;
    self.introduce.text=self.book.detail;
    self.navigationItem.title=@"详情介绍";
}

@end

//
//  SceneDelegate.h
//  BookManage
//
//  Created by qwe on 2021/7/2.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end


#import "ViewController.h"
#import "DetailController.h"
#import "Book.h"
@interface ViewController ()
@property(nonatomic,strong)NSArray *books;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tableView.rowHeight=90;
    self.navigationItem.title=@"书籍列表";
}
-(NSArray *)books{
    if (!_books) {
        _books=[Book books];
    }
    return _books;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    //获取跳转的目的的控制器
    UIViewController *vc=segue.destinationViewController;
    //判断是否是目的控制器
    if ([vc isKindOfClass:[DetailController class]]) {
        DetailController *detailVc=(DetailController *)vc;
        //获取单击行所在的索引
        NSIndexPath *Path=[self.tableView indexPathForSelectedRow];
        //选中行的模型
        Book *book=self.books[Path.row];
        detailVc.book = book;
    }
}


-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self performSegueWithIdentifier:@"one" sender:self];
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.books.count;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *ID=@"book";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:ID];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    //设置cell
    Book *book=self.books[indexPath.row];
    cell.textLabel.text=book.name;
    cell.imageView.image=[UIImage imageNamed:book.picture];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

@end

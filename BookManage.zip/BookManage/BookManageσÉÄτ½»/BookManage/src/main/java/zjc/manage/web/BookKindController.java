package zjc.manage.web;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import zjc.manage.dao.BookkindMapper;
import zjc.manage.domain.Bookkind;
import zjc.manage.domain.BookkindExample;
import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/BookManage")
public class BookKindController {


    @Resource
    private BookkindMapper bookkindMapper;

    @GetMapping("/findAllBookKind")
    public Object findAllBookKind() throws IOException {
        BookkindExample example = new BookkindExample();
        List<Bookkind> list = bookkindMapper.selectByExample(example);
        return makeJson(list);
    }

    @GetMapping("/findBookKind")
    public Object findBookKind(int bookkindId) throws IOException{

        BookkindExample example = new BookkindExample();
        example.or().andBookkindidEqualTo(bookkindId);
        List<Bookkind> list = bookkindMapper.selectByExample(example);
        return makeJson(list);
    }

    public Object makeJson(List<Bookkind> list) throws IOException {

        JSONArray jsonArray = new JSONArray();
        //循环获得数据
        for (Bookkind dc : list) {
            JSONObject jsonObj = new JSONObject();
            jsonObj.put("BookKindID", dc.getBookkindid());
            jsonObj.put("BookKindName", dc.getBookkindname());
            jsonArray.add(jsonObj);
        }

        JSONObject root = new JSONObject();
        root.put("result", jsonArray);
        return root;
    }


}

package zjc.manage.web;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import zjc.manage.dao.BookMapper;
import zjc.manage.domain.Book;
import zjc.manage.domain.BookExample;
import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/BookManage")
public class BookController {

    @Resource
    private BookMapper bookMapper;

    /*app端调用URL（http://127.0.0.1:8080/BookManage/findAllBook）时调用*/
    @GetMapping("/findAllBook")
    public Object findAllBook() throws IOException {
        BookExample example = new BookExample();
        List<Book> list = bookMapper.selectByExample(example);
        return makeJson(list);
    }

    /*app端调用URL（http://127.0.0.1:8080/BookManage/findBookByBookKindId? bookKindId=1）为1*/
    @GetMapping("/findBookByBookKindId")
    public Object findBookByBookKindId(int bookKindId) throws IOException {
        BookExample example = new BookExample();
        BookExample.Criteria criteria = example.createCriteria();
        criteria.andBookkindidEqualTo(bookKindId);
        List<Book> list = bookMapper.selectByExample(example);
        return makeJson(list);
    }

    /*app端调用URL（http://127.0.0.1:8080/BookManage/findBookById?bookId=1）*/
    @GetMapping("/findBookById")
    public Object findBookById(int bookId) throws IOException {
        BookExample example = new BookExample();
        BookExample.Criteria criteria = example.createCriteria();
        criteria.andBookidEqualTo(bookId);
        List<Book> list = bookMapper.selectByExample(example);
        return makeJson(list);
    }

    public Object makeJson(List<Book> list) throws IOException{
        JSONArray jsonArray = new JSONArray();
        for(Book dev: list){
            JSONObject jsonObj = new JSONObject();
            jsonObj.put("BookID", dev.getBookid());
            jsonObj.put("BookKindId", dev.getBookkindid());
            jsonObj.put("BookName", dev.getBookname());
            jsonObj.put("BookPrice", dev.getBookprice());
            jsonArray.add(jsonObj);
        }
        System.out.println(jsonArray.toString());
        JSONObject root = new JSONObject();
        root.put("result", jsonArray);
        return root;
    }
}

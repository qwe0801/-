package zjc.manage.service;

import zjc.manage.dao.BookkindMapper;
import javax.annotation.Resource;

public class BookKindService {
    @Resource
    private BookkindMapper bookkindMapper;





}
